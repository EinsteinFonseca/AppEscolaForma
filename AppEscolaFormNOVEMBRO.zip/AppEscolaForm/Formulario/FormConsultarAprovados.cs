﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppEscolaForm.Formulario
{
    public partial class FormConsultarAprovados : Form
    {
        public FormConsultarAprovados()
        {
            InitializeComponent();
        }
    }
}
