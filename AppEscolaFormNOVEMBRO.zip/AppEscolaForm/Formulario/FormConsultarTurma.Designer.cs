﻿namespace AppEscolaForm.Formulario
{
    partial class FormConsultarTurma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cbConsultaTurma = new System.Windows.Forms.ComboBox();
            this.dtLista = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dtLista)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(272, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Consulter Turma";
            // 
            // cbConsultaTurma
            // 
            this.cbConsultaTurma.FormattingEnabled = true;
            this.cbConsultaTurma.Location = new System.Drawing.Point(258, 82);
            this.cbConsultaTurma.Name = "cbConsultaTurma";
            this.cbConsultaTurma.Size = new System.Drawing.Size(121, 21);
            this.cbConsultaTurma.TabIndex = 1;
            // 
            // dtLista
            // 
            this.dtLista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtLista.Location = new System.Drawing.Point(29, 128);
            this.dtLista.Name = "dtLista";
            this.dtLista.Size = new System.Drawing.Size(730, 298);
            this.dtLista.TabIndex = 2;
            // 
            // FormConsultarTurma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dtLista);
            this.Controls.Add(this.cbConsultaTurma);
            this.Controls.Add(this.label1);
            this.Name = "FormConsultarTurma";
            this.Text = "FormConsultarTurma";
            ((System.ComponentModel.ISupportInitialize)(this.dtLista)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbConsultaTurma;
        private System.Windows.Forms.DataGridView dtLista;
    }
}