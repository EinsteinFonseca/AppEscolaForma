﻿namespace AppEscolaForm.Formulario
{
    partial class FormConsultarAprovados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.dtAlunosAprovados = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dtAlunosAprovados)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(212, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Consulta APROVADOS";
            // 
            // dtAlunosAprovados
            // 
            this.dtAlunosAprovados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtAlunosAprovados.Location = new System.Drawing.Point(27, 101);
            this.dtAlunosAprovados.Name = "dtAlunosAprovados";
            this.dtAlunosAprovados.Size = new System.Drawing.Size(743, 336);
            this.dtAlunosAprovados.TabIndex = 1;
            // 
            // FormConsultarAprovados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dtAlunosAprovados);
            this.Controls.Add(this.label1);
            this.Name = "FormConsultarAprovados";
            this.Text = "FormConsultarAprovados";
            ((System.ComponentModel.ISupportInitialize)(this.dtAlunosAprovados)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dtAlunosAprovados;
    }
}