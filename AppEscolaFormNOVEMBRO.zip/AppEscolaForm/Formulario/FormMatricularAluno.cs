﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppFormEscola.Models;
using AppEscolaForm.Contexto;


namespace AppEscolaForm.Formulario
{
    public partial class FormMatricularAluno : Form
    {
         List<Aluno> AlunoTemp = new List<Aluno>();
         Aluno alunos = new Aluno();
        public int IdTurma;

        
        public FormMatricularAluno()
        {
            InitializeComponent();
        }

        private void btSalvar_Click(object sender, EventArgs e)
        {

            alunos = new Aluno();
            alunos.Nome = txtNome.Text;
            alunos.Nota1 = Convert.ToInt32(txtNota1);
            alunos.Nota2 = Convert.ToInt32(txtNota2);




        }

        private void FormMatricularAluno_Load(object sender, EventArgs e)
        {

        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            Aluno aluno = new Aluno();
            aluno.Nome = txtNome.Text;
            aluno.Nota1 = Convert.ToInt32(aluno.Nota1);
            aluno.Nota2 = Convert.ToInt32(aluno.Nota2);
            aluno.Id = IdTurma;
            aluno.IdTurma = IdTurma;
            IdTurma++;

            AlunoTemp.Add(aluno);
            dtAluno.DataSource = AlunoTemp.ToList();
        }
    }
}
