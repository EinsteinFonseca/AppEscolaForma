﻿using AppEscolaForm.Formulario;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppEscolaForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btCadastrarSalaDeAula_Click(object sender, EventArgs e)
        {
            FormCadastrarSalaDeAula form = new FormCadastrarSalaDeAula();
            form.ShowDialog();
        }

        private void btmatricularAluno_Click(object sender, EventArgs e)
        {
            FormMatricularAluno form = new FormMatricularAluno();
            form.ShowDialog();
        }

        private void btConsultarAluno_Click(object sender, EventArgs e)
        {
            FormConsultarAlunos form = new FormConsultarAlunos();
            form.ShowDialog();
        }

        private void btConsultarTurmas_Click(object sender, EventArgs e)
        {
            FormConsultarTurma form = new FormConsultarTurma();
            form.ShowDialog();
        }

        private void btConsultarAlunosAprovados_Click(object sender, EventArgs e)
        {
           FormConsultarAprovados form = new FormConsultarAprovados();
            form.ShowDialog();
        }

        private void btConsultarAlunosReprovados_Click(object sender, EventArgs e)
        {
            FormConsultarReprovados form = new FormConsultarReprovados();
            form.ShowDialog();
        }

        private void btConsultarTurma_Click(object sender, EventArgs e)
        {
            FormTurmaPercentual form = new FormTurmaPercentual();
            form.ShowDialog();
        }
    }
}
