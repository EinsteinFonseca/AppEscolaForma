﻿namespace AppEscolaForm
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btConsultarTurma = new System.Windows.Forms.Button();
            this.btConsultarAlunosReprovados = new System.Windows.Forms.Button();
            this.btConsultarAlunosAprovados = new System.Windows.Forms.Button();
            this.btConsultarTurmas = new System.Windows.Forms.Button();
            this.btConsultarAluno = new System.Windows.Forms.Button();
            this.btmatricularAluno = new System.Windows.Forms.Button();
            this.btCadastrarSalaDeAula = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btConsultarTurma
            // 
            this.btConsultarTurma.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btConsultarTurma.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btConsultarTurma.Location = new System.Drawing.Point(23, 374);
            this.btConsultarTurma.Name = "btConsultarTurma";
            this.btConsultarTurma.Size = new System.Drawing.Size(474, 61);
            this.btConsultarTurma.TabIndex = 6;
            this.btConsultarTurma.Text = "CONSULTAR TURMA (PERCENTUAL DE APROVADOS E REPROVADOS DA TURMA)";
            this.btConsultarTurma.UseVisualStyleBackColor = true;
            this.btConsultarTurma.Click += new System.EventHandler(this.btConsultarTurma_Click);
            // 
            // btConsultarAlunosReprovados
            // 
            this.btConsultarAlunosReprovados.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btConsultarAlunosReprovados.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btConsultarAlunosReprovados.Location = new System.Drawing.Point(23, 313);
            this.btConsultarAlunosReprovados.Name = "btConsultarAlunosReprovados";
            this.btConsultarAlunosReprovados.Size = new System.Drawing.Size(474, 61);
            this.btConsultarAlunosReprovados.TabIndex = 5;
            this.btConsultarAlunosReprovados.Text = "CONSULTAR TURMAS( EXIBIR APENAS ALUNOS REPROVADOS)";
            this.btConsultarAlunosReprovados.UseVisualStyleBackColor = true;
            this.btConsultarAlunosReprovados.Click += new System.EventHandler(this.btConsultarAlunosReprovados_Click);
            // 
            // btConsultarAlunosAprovados
            // 
            this.btConsultarAlunosAprovados.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btConsultarAlunosAprovados.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btConsultarAlunosAprovados.Location = new System.Drawing.Point(23, 250);
            this.btConsultarAlunosAprovados.Name = "btConsultarAlunosAprovados";
            this.btConsultarAlunosAprovados.Size = new System.Drawing.Size(474, 61);
            this.btConsultarAlunosAprovados.TabIndex = 4;
            this.btConsultarAlunosAprovados.Text = "CONSULTAR TURMAS( EXIBIR APENAS ALUNOS APROVADOS)";
            this.btConsultarAlunosAprovados.UseVisualStyleBackColor = true;
            this.btConsultarAlunosAprovados.Click += new System.EventHandler(this.btConsultarAlunosAprovados_Click);
            // 
            // btConsultarTurmas
            // 
            this.btConsultarTurmas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btConsultarTurmas.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btConsultarTurmas.Location = new System.Drawing.Point(23, 189);
            this.btConsultarTurmas.Name = "btConsultarTurmas";
            this.btConsultarTurmas.Size = new System.Drawing.Size(474, 61);
            this.btConsultarTurmas.TabIndex = 3;
            this.btConsultarTurmas.Text = "CONSULTAR TURMAS (EXIBIR DADOS SALA DE AULA E ALUNOS MATRICULADOS)";
            this.btConsultarTurmas.UseVisualStyleBackColor = true;
            this.btConsultarTurmas.Click += new System.EventHandler(this.btConsultarTurmas_Click);
            // 
            // btConsultarAluno
            // 
            this.btConsultarAluno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btConsultarAluno.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btConsultarAluno.Location = new System.Drawing.Point(23, 134);
            this.btConsultarAluno.Name = "btConsultarAluno";
            this.btConsultarAluno.Size = new System.Drawing.Size(474, 61);
            this.btConsultarAluno.TabIndex = 2;
            this.btConsultarAluno.Text = "CONSULTAR ALUNO (EXIBIR DADOS E TURMA)";
            this.btConsultarAluno.UseVisualStyleBackColor = true;
            this.btConsultarAluno.Click += new System.EventHandler(this.btConsultarAluno_Click);
            // 
            // btmatricularAluno
            // 
            this.btmatricularAluno.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmatricularAluno.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btmatricularAluno.Location = new System.Drawing.Point(23, 77);
            this.btmatricularAluno.Name = "btmatricularAluno";
            this.btmatricularAluno.Size = new System.Drawing.Size(474, 61);
            this.btmatricularAluno.TabIndex = 1;
            this.btmatricularAluno.Text = "MATRICULAR ALUNO";
            this.btmatricularAluno.UseVisualStyleBackColor = true;
            this.btmatricularAluno.Click += new System.EventHandler(this.btmatricularAluno_Click);
            // 
            // btCadastrarSalaDeAula
            // 
            this.btCadastrarSalaDeAula.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCadastrarSalaDeAula.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btCadastrarSalaDeAula.Location = new System.Drawing.Point(23, 10);
            this.btCadastrarSalaDeAula.Name = "btCadastrarSalaDeAula";
            this.btCadastrarSalaDeAula.Size = new System.Drawing.Size(474, 61);
            this.btCadastrarSalaDeAula.TabIndex = 0;
            this.btCadastrarSalaDeAula.Text = "CADASTRAR SALA DE AULA";
            this.btCadastrarSalaDeAula.UseVisualStyleBackColor = true;
            this.btCadastrarSalaDeAula.Click += new System.EventHandler(this.btCadastrarSalaDeAula_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btConsultarTurma);
            this.Controls.Add(this.btConsultarAlunosReprovados);
            this.Controls.Add(this.btConsultarAlunosAprovados);
            this.Controls.Add(this.btConsultarTurmas);
            this.Controls.Add(this.btConsultarAluno);
            this.Controls.Add(this.btmatricularAluno);
            this.Controls.Add(this.btCadastrarSalaDeAula);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btCadastrarSalaDeAula;
        private System.Windows.Forms.Button btmatricularAluno;
        private System.Windows.Forms.Button btConsultarAluno;
        private System.Windows.Forms.Button btConsultarTurmas;
        private System.Windows.Forms.Button btConsultarAlunosAprovados;
        private System.Windows.Forms.Button btConsultarAlunosReprovados;
        private System.Windows.Forms.Button btConsultarTurma;
    }
}

