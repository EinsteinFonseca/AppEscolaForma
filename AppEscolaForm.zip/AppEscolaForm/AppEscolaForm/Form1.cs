﻿using AppEscolaForm.Formulario;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppEscolaForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormCadastrarSala form = new FormCadastrarSala();
            form.ShowDialog();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormMatricularAluno form = new FormMatricularAluno();
            form.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormConsultarAluno form = new FormConsultarAluno();
            form.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormConsultarTurmas form = new FormConsultarTurmas();
            form.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FormConsultarTurmaAprovados form = new FormConsultarTurmaAprovados();
            form.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            FormConsultarTurmaReprovados form = new FormConsultarTurmaReprovados();
            form.ShowDialog();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            FormConsultarTurmaPercentual form = new FormConsultarTurmaPercentual();
            form.ShowDialog();
        }
    }
}
