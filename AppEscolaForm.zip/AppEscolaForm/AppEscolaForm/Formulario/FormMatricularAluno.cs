﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppEscolaForm.Contexto;
using AppEscolaForm.Formulario;
using AppEscolaForm.Models;

namespace AppEscolaForm.Formulario
{
    public partial class FormMatricularAluno : Form
    {
        public static int idAluno = 1;
        public int idSalaDeAula;
        List<SalaDeAula> listaSalas = new List<SalaDeAula>();
        List<Aluno> listaAlunosTemp = new List<Aluno>();//lista temporária 
        int cont = 1;

        public FormMatricularAluno()
        {
            InitializeComponent();
            listaSalas = Context.ListaSalas.ToList();//trazer do banco
            cbTurma.DataSource = listaSalas.ToList();
            cbTurma.DisplayMember = "Turma";
            cbTurma.SelectedIndex = -1;
        }

        private void cbTurma_SelectedIndexChanged(object sender, EventArgs e)
        {
            int linhaSelec = cbTurma.SelectedIndex;
            if (linhaSelec > -1 && cont > 1)
            {
                var sala = listaSalas[linhaSelec];
                txtSerie.Text = sala.Serie.ToString();
                txtTurma.Text = sala.Turma;
                txtAno.Text = sala.Ano.ToString();
                idSalaDeAula = sala.Id;

            }
            cont++;
        }

        private void btAdd_Click(object sender, EventArgs e)
        {
            
            Aluno aluno = new Aluno();
            aluno.NumMatricula = idAluno*1000/*Convert.ToInt32(txtNumMatricula.Text)*/;
            
            aluno.Nome = txtNome.Text;
            aluno.Nota1 = Convert.ToDouble(txtNota1.Text);
            aluno.Nota2 = Convert.ToDouble(txtNota2.Text);
            aluno.Id = idAluno; //Chave primária 
            aluno.IdSalaDeAula = idSalaDeAula;//vinculando a multa ao veículo(chave estr) 
            listaAlunosTemp.Add(aluno);
            idAluno++;
            dtTabela.DataSource = listaAlunosTemp.ToList();//colocar na tabela as multas
            txtNome.Clear();
            txtNota1.Clear(); txtNota2.Clear();txtNome.Select();
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            txtNota1.Clear(); txtNota2.Clear(); txtNome.Select();
        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            Context.ListaAlunos.AddRange(listaAlunosTemp);//salvar uma lista de obj
            MessageBox.Show("SALVO COM SUCESSO!", "2A/INF", MessageBoxButtons.OK, MessageBoxIcon.Information);
             txtNome.Clear(); txtSerie.Clear(); txtAno.Clear(); txtTurma.Clear();
             txtNome.Clear(); txtSerie.Clear(); txtAno.Clear(); txtTurma.Clear();
            txtNota1.Clear(); txtNota2.Clear();  
            listaAlunosTemp.Clear();//limpar a lista temporária
            dtTabela.DataSource = listaAlunosTemp.ToList();/*limpar a tabela*/ txtNome.Select();
            cbTurma.SelectedIndex = -1; //limpar o combobox
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
