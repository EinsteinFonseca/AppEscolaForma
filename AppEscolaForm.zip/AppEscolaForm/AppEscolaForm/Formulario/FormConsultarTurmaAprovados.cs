﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppEscolaForm.Contexto;
using AppEscolaForm.Formulario;
using AppEscolaForm.Models;

namespace AppEscolaForm.Formulario
{
    public partial class FormConsultarTurmaAprovados : Form
    {
        List<SalaDeAula> listaSalas = new List<SalaDeAula>();
        List<Aluno> listaAlunos = new List<Aluno>();
        int cont = 1;
        public FormConsultarTurmaAprovados()
        {
            InitializeComponent();
            listaSalas = Context.ListaSalas.ToList();
            listaAlunos = Context.ListaAlunos.ToList();
            cbTurma.DataSource = listaSalas.ToList();
            cbTurma.DisplayMember = "Turma";
            cbTurma.SelectedIndex = -1;
        }

        private void cbTurma_SelectedIndexChanged(object sender, EventArgs e)
        {
            int linhaSelec = cbTurma.SelectedIndex;
            if (linhaSelec > -1 && cont > 1)
            {
                var sala = listaSalas[linhaSelec];
                txtSerie.Text = sala.Serie.ToString();
                txtTurma.Text = sala.Turma.ToString();
                txtAno.Text = sala.Ano.ToString();
                var alunoSelec = listaAlunos.Where(m => m.CalcularMedia() > 59 && m.IdSalaDeAula == sala.Id).ToList();
                dtTabela.DataSource = alunoSelec.ToList();
            }
            cont++;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
